<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>06-Paymentpage</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>ff219e0d-e186-450a-959a-5e2bd824efdd</testSuiteGuid>
   <testCaseLink>
      <guid>7f2be41e-934e-4ff6-892d-30197f57bd03</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Paymentpage</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d7e9a45a-4be7-44f9-a972-3bc68b05a0d4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cardnuminvalid</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3c7f5430-9a3c-44b2-8ec3-f0cba8eb6a6b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Passbankinvalid</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
