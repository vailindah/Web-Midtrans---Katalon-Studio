<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>04-Detail Order</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>3ae7a293-3197-46ea-88ca-02c35a932a2d</testSuiteGuid>
   <testCaseLink>
      <guid>c4e95a08-e357-484e-aa36-d3ddac58b8a2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Orderpage</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fadd04e3-cf16-4f45-ac01-02bd04b9db62</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Orderclose</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
