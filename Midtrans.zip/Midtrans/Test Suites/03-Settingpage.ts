<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>03-Settingpage</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>11b0b681-df5b-461d-8ef8-d0be66a4585b</testSuiteGuid>
   <testCaseLink>
      <guid>f1c5e3a8-78ef-43ea-b9c4-134f322c6d7e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Setting1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c5fa59e1-6593-4608-bb61-3ab044c4ee5b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Setting2</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
