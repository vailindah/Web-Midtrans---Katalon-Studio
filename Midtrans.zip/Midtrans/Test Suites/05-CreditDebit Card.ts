<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>05-CreditDebit Card</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>c7d681be-101b-4cbb-9cdc-f60c490cff79</testSuiteGuid>
   <testCaseLink>
      <guid>bfb8e3d5-6db7-41be-a64b-013614726734</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cardcancel</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6c9f88ef-8d79-4f53-811b-c3470b315aab</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cardfail</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3d67ca87-6501-43fc-bd7b-2c00f0bf3efd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cardnotpromo</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e60d629d-9025-4635-a756-f20f3f231179</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Carddone</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
