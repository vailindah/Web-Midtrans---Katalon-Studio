<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>02-Shopping Cart</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>62e7544d-f30d-48a9-b1b6-384fe763198f</testSuiteGuid>
   <testCaseLink>
      <guid>0794cd33-747c-4bb7-9a42-eadf099870a1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cartcancel</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1ca29386-b9f2-4a52-b48f-791356b1e83b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cartcheckout</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>aacaaba5-47fc-4ff4-be4e-c81ed8ff59de</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Carterror</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
