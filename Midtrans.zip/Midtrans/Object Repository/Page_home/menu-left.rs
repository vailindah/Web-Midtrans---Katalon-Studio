<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>menu-left</name>
   <tag></tag>
   <elementGuidId>4f20e495-5af9-402d-bc98-ec5f7435259c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//i[@class='glyphicon glyphicon-menu-left']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>i.glyphicon.glyphicon-menu-left</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glyphicon glyphicon-menu-left</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-reactid</name>
      <type>Main</type>
      <value>.0.0.0.1.1.0.0</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;carousel&quot;)/div[@class=&quot;control&quot;]/a[@class=&quot;control-button&quot;]/i[@class=&quot;glyphicon glyphicon-menu-left&quot;]</value>
   </webElementProperties>
</WebElementEntity>
