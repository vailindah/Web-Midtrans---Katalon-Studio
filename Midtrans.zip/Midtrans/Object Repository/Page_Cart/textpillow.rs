<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>textpillow</name>
   <tag></tag>
   <elementGuidId>ecd91623-59ad-4912-818e-acb398843cb2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[3]/input</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
